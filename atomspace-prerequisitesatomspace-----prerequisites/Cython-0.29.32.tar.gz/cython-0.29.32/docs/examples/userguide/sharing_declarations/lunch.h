void eject_tomato(float speed);
